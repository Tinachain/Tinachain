export * from '@app/core/components/mixins/mixin-number-string-concat'
