export interface TokenHolder {
  address: string
  balance: string
}
