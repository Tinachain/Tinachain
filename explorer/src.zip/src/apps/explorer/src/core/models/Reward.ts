export interface Reward {
  rewardType: string
  address: string
  value: string
}
