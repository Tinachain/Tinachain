export interface CoinExchangeRate {
  currency: string
  price: number
  marketCap: number
  lastUpdated: number
  vol24h: string
}
