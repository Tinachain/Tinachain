export interface Statistic {
  date: number
  value: number
}
