/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: TokenHolder
// ====================================================

export interface TokenHolder {
  __typename: "TokenHolder";
  address: string;
  balance: any;
}
