/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: ContractSummary
// ====================================================

export interface ContractSummary {
  __typename: "ContractSummary";
  address: string;
  creator: string;
  blockNumber: any;
  txHash: string;
  timestamp: number;
  txFee: any;
}
