/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: AvgDifficultyMetric
// ====================================================

export interface AvgDifficultyMetric {
  __typename: "AggregateBlockMetric";
  timestamp: any;
  value: any | null;
}
