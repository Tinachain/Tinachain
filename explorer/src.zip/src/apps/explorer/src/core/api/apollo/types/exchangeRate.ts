/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: exchangeRate
// ====================================================

export interface exchangeRate_exchangeRate {
  __typename: "CoinExchangeRate";
  price: any | null;
}

export interface exchangeRate {
  exchangeRate: exchangeRate_exchangeRate | null;
}
