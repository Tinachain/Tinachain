/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: Account
// ====================================================

export interface Account {
  __typename: "Account";
  address: string;
  balance: any;
  totalTxCount: any;
  inTxCount: any;
  outTxCount: any;
  isMiner: boolean;
  isContractCreator: boolean;
  isContract: boolean;
}
