/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: AvgNumFailedTxsMetric
// ====================================================

export interface AvgNumFailedTxsMetric {
  __typename: "AggregateBlockMetric";
  timestamp: any;
  value: number | null;
}
