/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: AvgGasLimitMetric
// ====================================================

export interface AvgGasLimitMetric {
  __typename: "AggregateBlockMetric";
  timestamp: any;
  value: any | null;
}
