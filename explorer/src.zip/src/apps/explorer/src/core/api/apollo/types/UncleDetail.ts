/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: UncleDetail
// ====================================================

export interface UncleDetail {
  __typename: "Uncle";
  author: string;
  number: any;
  gasLimit: any;
  gasUsed: any;
  hash: string;
  parentHash: string;
  sha3Uncles: string;
  timestamp: number;
  nephewNumber: any;
  uncleIndex: number;
}
