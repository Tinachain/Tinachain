/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: CoinExchangeRate
// ====================================================

export interface CoinExchangeRate {
  __typename: "CoinExchangeRate";
  price: any | null;
}
