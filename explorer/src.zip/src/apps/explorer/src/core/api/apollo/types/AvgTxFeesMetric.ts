/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: AvgTxFeesMetric
// ====================================================

export interface AvgTxFeesMetric {
  __typename: "AggregateBlockMetric";
  timestamp: any;
  value: any | null;
}
