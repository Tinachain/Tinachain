/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: AvgNumSuccessfulTxsMetric
// ====================================================

export interface AvgNumSuccessfulTxsMetric {
  __typename: "AggregateBlockMetric";
  timestamp: any;
  value: number | null;
}
