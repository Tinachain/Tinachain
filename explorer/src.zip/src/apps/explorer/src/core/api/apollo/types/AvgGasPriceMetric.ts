/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: AvgGasPriceMetric
// ====================================================

export interface AvgGasPriceMetric {
  __typename: "AggregateBlockMetric";
  timestamp: any;
  value: any | null;
}
