/* tslint:disable */
/* eslint-disable */
// This file was automatically generated and should not be edited.

import { SearchType } from "./globalTypes";

// ====================================================
// GraphQL fragment: SearchResult
// ====================================================

export interface SearchResult {
  __typename: "Search";
  type: SearchType;
}
