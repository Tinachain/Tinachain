export * from '@app/modules/charts/mixins/mixin-chart'
