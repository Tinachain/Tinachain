declare module '*.graphql'
