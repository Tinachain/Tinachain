package com.ethvm.kafka.connect.sources.web3

object Versions {

  const val CURRENT = "0.1.0"
}
