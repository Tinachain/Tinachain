package com.ethvm.kafka.connect.sources.tokens

object Versions {

  const val CURRENT = "0.1.0"
}
