package com.ethvm.kafka.connect.sources.exchanges.utils

object Versions {

  const val CURRENT = "0.1.0"
}
