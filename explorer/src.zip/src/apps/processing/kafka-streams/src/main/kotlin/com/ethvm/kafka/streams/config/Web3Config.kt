package com.ethvm.kafka.streams.config

data class Web3Config(
  val wsUrl: String
)
