package com.ethvm.kafka.streams

fun main(args: Array<String>) {
  com.ethvm.kafka.streams.Cli().main(args)
}
